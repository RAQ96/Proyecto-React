import './PaginaNoEncontrada.css';

const PaginaNoEncontrada = () => {
  return <h1>Página no encontrada</h1>;
};

export default PaginaNoEncontrada;
