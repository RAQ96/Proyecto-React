import './MasVendidos.css';

const MasVendidos = () => {
  return <h1>Más vendidos</h1>;
};

export default MasVendidos;
