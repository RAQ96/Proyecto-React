import './Nosotros.css';

const Nosotros = () => {
  return <h1>Nosotros</h1>;
};

export default Nosotros;
