import './Novedades.css';

const Novedades = () => {
  return <h1>Novedades</h1>;
};

export default Novedades;
